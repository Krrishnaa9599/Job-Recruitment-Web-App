package com.jalatech.mysqlconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

	
	  public Connection getDatabaseConnection(){
	  try {
	  Class.forName("com.mysql.jdbc.Driver"); 
	  }
	  catch (ClassNotFoundException e1) {
	  e1.printStackTrace(); 
	  }
	  
	   Connection con=null;
	 
	  try {
	  con=DriverManager.getConnection("jdbc:mysql://localhost:3306/jalatechlatest",
	  "root","krrishnaa");
	  
	  } 
	  catch (SQLException e) 
	  { 
		  e.printStackTrace(); 
	  }
	  return con;
	  
	  }
	 
	
	/*
	 * public Connection getDatabaseConnection(){ try {
	 * Class.forName("oracle.jdbc.driver.OracleDriver"); } catch
	 * (ClassNotFoundException e1) { e1.printStackTrace(); }
	 * 
	 * Connection con=null;
	 * 
	 * try {
	 * con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:oracle",
	 * "system", "krrishnaa");
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } return con;
	 * 
	 * }
	 */

}
