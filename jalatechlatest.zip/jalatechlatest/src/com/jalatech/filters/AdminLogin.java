package com.jalatech.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.jalatech.mysqlconnection.DatabaseConnection;


public class AdminLogin implements Filter {

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		DatabaseConnection dc=new DatabaseConnection();
		Connection con=dc.getDatabaseConnection();
		
		try {
			Statement  st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from admin");
			if(rs.next()==false){
				out.println("<!DOCTYPE html>");
				out.println("<html lang='en'>");
				out.println("<head>");
				out.println("<title>Admin Login</title>");
				out.println("<link rel='stylesheet' type='text/css' href='CSS/adminlogin.css'>");
				out.println("</head>");
				out.println("<body>");
				out.println("<div id='box1'>");
				out.println("");
				out.println("</div>");
				out.println("<div id='box2'>");
				out.println("<div id='loginbox'>");
				out.println("<h1 style='text-align:center'>Admin</h1>");
				out.println("<form method='post' action='./adminhome'>");
				out.println("<table>");
				out.println("<tr>");
				out.println("<td><label>Username</label></td>");
				out.println("</tr>");
				out.println("<tr style='height:70px;vertical-align: top;'>");
				out.println("<td><input type='text' id='username' name='username'><p>There are no admins for this Website.Please register an account for admin in database manully</p></td>");
				out.println("");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<td><label>Password</label></td>");
				out.println("</tr>");
				out.println("<tr style='height:80px;vertical-align: top;'>");
				out.println("<td><input type='password' id='password' name='password'><p> </p></td>");
				out.println("");
				out.println("<tr style='text-align:center'>");
				out.println("<td><input id='button' value='LOGIN' type='submit'></td>");
				out.println("</tr>");
				out.println("</table>");
				out.println("</form>");
				out.println("</div>");
				out.println("</div>");
				out.println("<script src='JAVASCRIPT/adminlogin.js'></script>");
				out.println("</body>");
				out.println("</html>");
			}
			else {
				boolean presentUsername=false;
				boolean presentPassword=false;
				String incorrectPassword="";
				String usernameExists="";
				rs.beforeFirst();
				while(rs.next())
				{
					if(request.getParameter("username").trim().equalsIgnoreCase(rs.getString(2)))
					{
						presentUsername=true;
						if(request.getParameter("password").equals(rs.getString(3)))
						{
							presentPassword=true;
							break;
						}
						break;
					}
				}
				
				if(presentUsername==true && presentPassword==false)
				{
					incorrectPassword="Incorrect Password";
				}
				else if(presentUsername==false && presentPassword==false)
				{
					usernameExists="Username does not exists";
				}
				if(incorrectPassword.equals("Incorrect Password") || usernameExists.equals("Username does not exists"))
				{
				out.println("<!DOCTYPE html>");
				out.println("<html lang='en'>");
				out.println("<head>");
				out.println("<title>Admin Login</title>");
				out.println("<link rel='stylesheet' type='text/css' href='CSS/adminlogin.css'>");
				out.println("</head>");
				out.println("<body>");
				out.println("<div id='box1'>");
				out.println("");
				out.println("</div>");
				out.println("<div id='box2'>");
				out.println("<div id='loginbox'>");
				out.println("<h1 style='text-align:center'>Admin</h1>");
				out.println("<form method='post' action='./adminhome'>");
				out.println("<table>");
				out.println("<tr>");
				out.println("<td><label>Username</label></td>");
				out.println("</tr>");
				out.println("<tr style='height:70px;vertical-align: top;'>");
				out.println("<td><input type='text' id='username' name='username' value='"+request.getParameter("username").trim()+"'><p>"+usernameExists+"</p></td>");
				out.println("</tr>");
				out.println("<tr>");
				out.println("<td><label>Password</label></td>");
				out.println("</tr>");
				out.println("<tr style='height:80px;vertical-align: top;'>");
				out.println("<td><input type='password' id='password' name='password'><p>"+incorrectPassword+"</p></td>");
				out.println("");
				out.println("<tr style='text-align:center'>");
				out.println("<td><input id='button' value='LOGIN' type='submit'></td>");
				out.println("</tr>");
				out.println("</table>");
				out.println("</form>");
				out.println("</div>");
				out.println("</div>");
				out.println("<script src='JAVASCRIPT/adminlogin.js'></script>");
				out.println("</body>");
				out.println("</html>");
				}
				else
				{
					chain.doFilter(request, response);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
