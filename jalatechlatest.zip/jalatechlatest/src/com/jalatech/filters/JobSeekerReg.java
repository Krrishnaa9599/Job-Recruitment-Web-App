package com.jalatech.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.jalatech.mysqlconnection.DatabaseConnection;


public class JobSeekerReg implements Filter {
	
	public void destroy() {

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Connection con=null;
		ResultSet rs=null;
		
		try {
			DatabaseConnection dc=new DatabaseConnection();
			con=dc.getDatabaseConnection();
			Statement st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			rs=st.executeQuery("select * from jobseekerreg");
			
			if(rs.next()==false)
			{
				rs.moveToInsertRow();
				rs.updateString(2,request.getParameter("firstname").trim());
				rs.updateString(3,request.getParameter("lastname").trim());
				rs.updateDate(4,java.sql.Date.valueOf(request.getParameter("dob").trim()));
				rs.updateString(5,request.getParameter("gender").trim());
				rs.updateDate(6,java.sql.Date.valueOf(request.getParameter("jdate").trim()));
				rs.updateString(7,request.getParameter("mobileno").trim());
				rs.updateString(8,request.getParameter("email").trim());
				rs.updateString(9,request.getParameter("password"));
				
				rs.insertRow();
				chain.doFilter(request, response);
			}
			else
			{
				rs.beforeFirst();
				boolean present=false;
				while(rs.next())
				{
					if((rs.getString(8).trim()).equalsIgnoreCase(request.getParameter("email").trim()))
					{
						present=true;
						break;
					}
				}
				if(present)
				{
					out.println("<!DOCTYPE html>");
					out.println("<html lang='en'>");
					out.println("<head>");
					out.println("<title>Job Seeker Registration</title>");
					out.println("<link rel='stylesheet' type='text/css' href='CSS/jobseekerreg.css'>");
					out.println("</head>");
					out.println("<body>");
					out.println("<div id='regblock'>");
					out.println("<h1 style='text-align: center;'>JOB SEEKER REGISTRATION</h1>");
					out.println("<form method='post' action='./jobseekerregsuccess'>");
					out.println("<table id=table1>");
					out.println("<tr style='height: 20px;padding: 0;'>");
					out.println("<td style='padding: 0;'><label for='firstname'>FIRST NAME</label></td>");
					out.println("<td style='padding: 0;'><label for='lastname'>LAST NAME</label></td>");
					out.println("<td style='padding: 0;'><label for='dob'>DATE OF BIRTH</label></td>");
					out.println("</tr>");
					out.println("<tr style='vertical-align:top;height: 40%;'>");
					out.println("<td><input id='firstname' name='firstname' type='text'><p> </p></td>");
					out.println("<td><input id='lastname' name='lastname' type='text'><p> </p></td>");
					out.println("<td><input id='dob' name='dob' type='date'><p> </p></td>");
					out.println("</tr>");
					out.println("<tr style='height: 20px;'>");
					out.println("<td><label for='gender'>GENDER</label></td>");
					out.println("<td><label for='jdate'>JOINING DATE</label></td>");
					out.println("<td><label for='mobileno'>MOBILE NO</label></td>");
					out.println("</tr>");
					out.println("<tr style='vertical-align:top;height: 40%;'>");
					out.println("<td><input id='male' name='gender' type='radio' value='male'><span>Male</span>");
					out.println("<input id='female' name='gender' type='radio' value='female'><span>Female</span>");
					out.println("<input id='others' name='gender' type='radio' value='others'><span>Others</span><p> </p></td>");
					out.println("<td><input type='date' name='jdate' id='jdate'><p> </p></td>");
					out.println("<td><input type='text' name='mobileno' id='mobileno'><p> </p></td>");
					out.println("</tr>");
					out.println("</table>");
					out.println("<table id='table2'>");
					out.println("<tr style='height: 20%;'>");
					out.println("<td><label style='font-size: 20px;' for='email'>USER NAME</label></td>");
					out.println("<td style='vertical-align: top;'><input type='text' id='email' name='email' placeholder='must be a valid email address'><p>Username already exists</p></td>");
					out.println("</tr>");
					out.println("<tr style='height: 20%;'>");
					out.println("<td><label style='font-size: 20px;' for='password'>PASSWORD</label></td>");
					out.println("<td style='vertical-align: top;'><input type='password' name='password' id='password'><p> </p></td>");
					out.println("</tr>");
					out.println("<tr style='height: 20%;'>");
					out.println("<td><label style='font-size: 20px;' for='repassword'>RE-ENTER PASSWORD</label></td>");
					out.println("<td style='vertical-align: top;'><input id='repassword' name='repassword' type='password'><p> </p></td>");
					out.println("</tr>");
					out.println("</table>");
					out.println("<input id='button' type='submit' value='SUBMIT'>");
					out.println("</form>");
					out.println("</div>");
					out.println("<script src='JAVASCRIPT/jobseekerreg.js'></script>");
					out.println("</body>");
					out.println("</html>");
				}
				else
				{
					rs.moveToInsertRow();
					rs.updateString(2,request.getParameter("firstname").trim());
					rs.updateString(3,request.getParameter("lastname").trim());
					rs.updateDate(4,java.sql.Date.valueOf(request.getParameter("dob").trim()));
					rs.updateString(5,request.getParameter("gender").trim());
					rs.updateDate(6,java.sql.Date.valueOf(request.getParameter("jdate").trim()));
					rs.updateString(7,request.getParameter("mobileno").trim());
					rs.updateString(8,request.getParameter("email").trim());
					rs.updateString(9,request.getParameter("password"));
					
					rs.insertRow();
					chain.doFilter(request, response);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}

	public void init(FilterConfig fConfig) throws ServletException {

	}

}
