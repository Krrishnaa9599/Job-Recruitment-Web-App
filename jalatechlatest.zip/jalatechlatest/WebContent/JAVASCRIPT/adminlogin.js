const button=document.querySelector("#button");
const username=document.querySelector("#username");
const password=document.querySelector("#password");

button.addEventListener("click",sub);

function sub(e){
  const errmsg=new Array();

  if(username.value.trim()===""){
    username.nextSibling.textContent="Do not leave empty";
    username.style.borderColor="red";
    errmsg.push(false);
  }
  if(password.value===""){
    password.nextSibling.textContent="Do not leave empty";
    password.style.borderColor="red";
    errmsg.push(false);
  }
  setTimeout(function(){
    username.nextSibling.textContent=" ";
    password.nextSibling.textContent=" ";
    
    username.style.borderColor="green";
    password.style.borderColor="green";
  },5000);
  if(errmsg.length>0){
    e.preventDefault();
  }
}