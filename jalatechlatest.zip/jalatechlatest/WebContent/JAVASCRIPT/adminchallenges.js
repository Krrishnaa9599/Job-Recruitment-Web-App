document.querySelector('body').addEventListener('click',table);
//document.querySelector('body').addEventListener('click',findout);

// function findout(e){
//   console.log("Found: "+e.target.id);
//   e.preventDefault();
// }

function table(e){
  //console.log('called table function');
  //console.log(e.target);
  if(e.target.id==='newsection'){
    //console.log(e.target.parentElement.parentElement.parentElement.parentElement.tagName);
    //console.log(e.target.parentElement.parentElement.parentElement.parentElement.id);
    const id=e.target.parentElement.parentElement.parentElement.parentElement.id;
    const num=parseInt(id.substring(5));
    //console.log(num);

    const tr=document.createElement('tr');
    const th=document.createElement('th');
    th.setAttribute('colspan','5');
    th.style.backgroundColor="#8DB4E2";
    th.color='white';
    const input=document.createElement('input');
    input.style.width="100%";
    input.style.textAlign='center';
    input.setAttribute('placeholder','Enter Section Name');
    input.style.border='none';
    th.appendChild(input);
    tr.appendChild(th);

    const th2=document.createElement('th');
    //save
    const save=document.createElement('a');
    save.appendChild(document.createTextNode("Save"));
    save.style.padding="5px 10px 5px 10px";
    save.style.backgroundColor="green";
    save.href="";
    //save.href='./adminchallengessection?section=1';//./adminchallenge
    save.id='newsectionsave'
    save.style.textDecoration='none';
    save.style.color='white';
    th2.appendChild(save);
    //save

    //delete
    const deletebutton=document.createElement('a');
    deletebutton.appendChild(document.createTextNode("Delete"));
    deletebutton.style.padding='5px 10px 5px 10px';
    deletebutton.style.backgroundColor='red';
    deletebutton.style.textDecoration='none';
    deletebutton.style.color='white';
    deletebutton.href="";
    deletebutton.id='newsectiondelete';
    th2.appendChild(deletebutton);
    //delete

    th2.style.width="15%";
    th2.style.border="1px solid white";
    th2.style.borderLeft=" 1px solid black";
    tr.appendChild(th2);

    const thead=document.createElement('thead');
    thead.id='header'+(num+1);
    thead.appendChild(tr);

    const tbody=document.createElement('tbody');
    tbody.id='body'+(num+1);
    const tr2=document.createElement('tr');
    // input.style.width="100%";
    // input.style.textAlign='center';
    // input.setAttribute('placeholder','Enter Section Name');
    // input.style.border='none';
    tr2.innerHTML=`
    <td rowspan="2" style="width: 5%;">1</td>
    <td rowspan="2" style="width: 5%;"><input id='priority' name='priority' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Priority'></td>
    <td rowspan="2" style="width: 20%;"><input id='subject' name='subject' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Subject Name'></td>
    <td style="width: 50%;"><input id='challenge' name='challenge' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'></td>
    <td style="width: 5%;"><input id='points' name='points' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Points'></td>
    <td id="adddeleteeditsave" style='width: 15%;border:1px solid white;border-left: 1px solid black;'><a href='' id='saverecord'>Save</a><a href='' id='deleterecord'>Delete</a></td>
        `;

    const tfoot=document.createElement('tfoot');
    tfoot.id="foot"+(num+1);
    const tr3=document.createElement('tr');
    tr3.innerHTML=`
    <td colspan="3" style="background-color: #E6B8B7;"></td>
    <td style="width: 50%;background-color: #E6B8B7;">Total</td>
    <td style="width: 5%;background-color: #E6B8B7;">Points</td>
    <td style="width: 15%;border:1px solid white;border-left: 1px solid black;"><a href="" id="newsection">Add New Section</a></td>`;
    tbody.appendChild(tr2);
    tfoot.appendChild(tr3);

    const finaltable=document.createElement('table');
    finaltable.id='table'+(num+1);
    finaltable.setAttribute('border','1');
    finaltable.appendChild(thead);
    finaltable.appendChild(tbody);
    finaltable.appendChild(tfoot);


    console.log('current table idno='+num);
    
    let ele=e.target.parentElement.parentElement.parentElement.parentElement.nextElementSibling;
    if(ele!=null){
      let idno=num+2;
      while(ele!=null){
      ele.id='table'+idno;
      ele.children[0].id='header'+idno;
      ele.children[1].id='body'+idno;
      ele.children[2].id='foot'+idno;
      idno=idno+1;
      console.log(ele);
      ele=ele.nextElementSibling;
      }
      document.querySelector('#heading').insertBefore(finaltable,document.querySelector('#table'+(num+2)));
    }
    else{
      console.log('else called');
      document.querySelector('#heading').appendChild(finaltable);
    }

    e.preventDefault();
  }
  if(e.target.id==='newsectionsave'){
    console.log('new section saved');

    const invalue=e.target.parentElement.previousElementSibling.firstElementChild.value;
    e.target.parentElement.previousElementSibling.firstElementChild.remove();
    e.target.parentElement.previousElementSibling.appendChild(document.createTextNode(invalue));
    e.target.parentElement.id='adddeleteeditsave';
    e.target.parentElement.innerHTML=`<a href="" id="add">Add</a><a href="" id="delete">Delete</a><a href="" id="edit">Rename</a>`;
    e.preventDefault();
  }
  //add
  if(e.target.id==='add'){
    console.log('add button clicked');
    if(e.target.parentElement.tagName==='TD'){
    const bodytag=e.target.parentElement.parentElement.parentElement;

    const tr=document.createElement('tr');
    tr.innerHTML=`
    <td style="width: 50%;"><input id='challenge' name='challenge' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'></td>
    <td style="width: 5%;"><input id='points' name='points' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Points'></td>
        <td id="adddeleteeditsave" style='width: 15%;border:1px solid white;border-left: 1px solid black;'><a href='' id='saverecord'>Save</a><a href='' id='deleterecord'>Delete</a></td>`;
    
    let rowsp=parseInt(bodytag.firstElementChild.children[0].getAttribute('rowspan'));
    rowsp=rowsp+1;
    bodytag.firstElementChild.children[0].setAttribute('rowspan',rowsp);
    bodytag.firstElementChild.children[1].setAttribute('rowspan',rowsp);
    bodytag.firstElementChild.children[2].setAttribute('rowspan',rowsp);

    bodytag.insertBefore(tr,e.target.parentElement.parentElement.nextElementSibling);    
    }
    else if(e.target.parentElement.tagName==='TH'){
      const id=e.target.parentElement.parentElement.parentElement.id;
      const numss=parseInt(id.substring(6));
      
      const sno=document.querySelector('#body'+numss).firstElementChild.children[0];
      const priority=document.querySelector('#body'+numss).firstElementChild.children[1];
      const subject=document.querySelector('#body'+numss).firstElementChild.children[2];

      let rowsp=parseInt(document.querySelector('#body'+numss).firstElementChild.children[0].getAttribute('rowspan'));
      const tr=document.createElement('tr');
      tr.innerHTML=`
          <td rowspan="${rowsp+1}" style="width: 5%;">${sno.textContent}</td>
          <td rowspan="${rowsp+1}" style="width: 5%;">${priority.textContent}</td>
          <td rowspan="${rowsp+1}" style="width: 20%;">${subject.textContent}</td>
          <td style="width: 50%;"><input id='challenge' name='challenge' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'></td>
    <td style="width: 5%;"><input id='points' name='points' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Points'></td>
          <td id="adddeleteeditsave" style='width: 15%;border:1px solid white;border-left: 1px solid black;'><a href='' id='saverecord'>Save</a><a href='' id='deleterecord'>Delete</a></td>`;
      sno.remove();
      priority.remove();
      subject.remove();

      document.querySelector('#body'+numss).insertBefore(tr,document.querySelector('#body'+numss).firstElementChild);
    }
    e.preventDefault();
  }
  //add
  //save record
  if(e.target.id==='saverecord'||e.target.id==='save'){
    console.log('save record clicked');
    ///[0-9]/i.test('2')
    console.log(e.target.parentElement.parentElement.firstElementChild.getAttribute('rowspan'));
    const partr=e.target.parentElement.parentElement;
    let childno=0;
    let ele=partr.children[0];
    while(ele!=null){
      ele=ele.nextElementSibling;
      childno=childno+1;
    }
    if(childno>3){
      //6
      if(e.target.parentElement.parentElement.parentElement.previousElementSibling.children[0].children[0].tagName==='TH'&&e.target.parentElement.parentElement.children[1].firstElementChild==null){
        
        console.log('ENTERED');
        console.log(e.target.parentElement.parentElement.parentElement.previousElementSibling.children[0].children[0].tagName);
        console.log(e.target.parentElement.parentElement.children[1].firstElementChild);
        
        const challenge=e.target.parentElement.parentElement.children[3].firstElementChild;
        const points=e.target.parentElement.parentElement.children[4].firstElementChild;
     //console.log();
        e.target.parentElement.parentElement.children[3].appendChild(document.createTextNode(challenge.value.trim()));
        e.target.parentElement.parentElement.children[4].appendChild(document.createTextNode(points.value.trim()));

        challenge.remove();
        points.remove();
      }
      else{
      const priority=e.target.parentElement.parentElement.children[1].firstElementChild;
      const subject=e.target.parentElement.parentElement.children[2].firstElementChild;
      const challenge=e.target.parentElement.parentElement.children[3].firstElementChild;
      const points=e.target.parentElement.parentElement.children[4].firstElementChild;
      console.log('FIRST ROW');
      e.target.parentElement.parentElement.children[1].appendChild(document.createTextNode(priority.value.trim()));
      e.target.parentElement.parentElement.children[2].appendChild(document.createTextNode(subject.value.trim()));
      e.target.parentElement.parentElement.children[3].appendChild(document.createTextNode(challenge.value.trim()));
      e.target.parentElement.parentElement.children[4].appendChild(document.createTextNode(points.value.trim()));
      priority.remove();
      subject.remove();
      challenge.remove();
      points.remove();
      }
    }
    else{
      //3
      const challenge=e.target.parentElement.parentElement.children[0].firstElementChild;
      const points=e.target.parentElement.parentElement.children[1].firstElementChild;
      console.log('REMAINING ROWS BUT NOT FIRST ROW');

      e.target.parentElement.parentElement.children[0].appendChild(document.createTextNode(challenge.value.trim()));
      e.target.parentElement.parentElement.children[1].appendChild(document.createTextNode(points.value));

      challenge.remove();
      points.remove();
      console.log("SAVED REMAINING ROW CHALLENGE AND POINTS");
    } 
    if(e.target.id==='save'&&e.target.parentElement.tagName!='TH'&&e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].firstElementChild!=null){
      const priority=e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].firstElementChild;
      const subject=e.target.parentElement.parentElement.parentElement.firstElementChild.children[2].firstElementChild;

      e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].textContent=priority.value.trim();
      e.target.parentElement.parentElement.parentElement.firstElementChild.children[2].textContent=subject.value.trim();

      priority.remove();
      subject.remove();
      console.log("SAVED REMAINING ROW PRIORITY AND SUBJECT");
    }
    const par=e.target.parentElement;
    // const saverec=par.children[0];
    // const delrec=par.children[1];

    // saverec.remove();
    // delrec.remove();

    par.innerHTML=`
        <a href="" id="add">Add</a><a href="" id="delete">Delete</a><a href="" id="edit">Rename</a>`;
    
    e.preventDefault();
  }
  //save record

  if(e.target.id==='deleterecord'||e.target.id==='delete'||e.target.id==='newsectiondelete'){
      if(e.target.parentElement.tagName==='TH' && (e.target.id==='delete'||e.target.id==='newsectiondelete')){
        //e.target.parentElement.parentElement.parentElement.parentElement.remove();
        console.log('deleterecord1');
        const tabl=e.target.parentElement.parentElement.parentElement.parentElement;
        const id=tabl.id;
        const numss=parseInt(id.substring(5));
        console.log('table'+numss);
        let ele=tabl.nextElementSibling;
        let idno=0;
        let n=0;
        while(ele!=null){
          n=parseInt(ele.id.substring(5));
          n=n-1;
          ele.children[0].setAttribute('id','header'+n);
          ele.children[1].setAttribute('id','body'+n);
          ele.children[2].setAttribute('id','foot'+n);
          ele.id=ele.id.substring(0,5)+n;
          ele=ele.nextElementSibling;
        }
        tabl.remove();
      }
      else if(e.target.parentElement.parentElement!=e.target.parentElement.parentElement.parentElement.firstElementChild){
        let rs=parseInt(e.target.parentElement.parentElement.parentElement.firstElementChild.firstElementChild.getAttribute('rowspan'));
        e.target.parentElement.parentElement.parentElement.firstElementChild.children[0].setAttribute('rowspan',rs-1);
        e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].setAttribute('rowspan',rs-1);
        e.target.parentElement.parentElement.parentElement.firstElementChild.children[2].setAttribute('rowspan',rs-1);
        e.target.parentElement.parentElement.remove();
      }
      // console.log(e.target.parentElement.parentElement);
      // console.log(e.target.parentElement.parentElement.parentElement);
      // console.log(e.target);
      else if(e.target.parentElement.parentElement==e.target.parentElement.parentElement.parentElement.firstElementChild){
        if(e.target.parentElement.parentElement.nextElementSibling!=null){
          console.log('1 or more siblings');
          let num=parseInt(e.target.parentElement.parentElement.children[0].getAttribute('rowspan'));
          e.target.parentElement.parentElement.children[0].setAttribute('rowspan',num-1);
          e.target.parentElement.parentElement.children[1].setAttribute('rowspan',num-1);
          e.target.parentElement.parentElement.children[2].setAttribute('rowspan',num-1);
          const priority=e.target.parentElement.parentElement.children[0];
          const subject=e.target.parentElement.parentElement.children[1];
          const challenge=e.target.parentElement.parentElement.children[2];
          e.target.parentElement.parentElement.nextElementSibling.insertBefore(challenge,e.target.parentElement.parentElement.nextElementSibling.firstElementChild);
          e.target.parentElement.parentElement.nextElementSibling.insertBefore(subject,e.target.parentElement.parentElement.nextElementSibling.firstElementChild);
          e.target.parentElement.parentElement.nextElementSibling.insertBefore(priority,e.target.parentElement.parentElement.nextElementSibling.firstElementChild);
          e.target.parentElement.parentElement.remove();
        }
        else{
          console.log('no siblings');
          const tabl=e.target.parentElement.parentElement.parentElement.parentElement;
          const id=tabl.id;
          const numss=parseInt(id.substring(5));
          console.log('table'+numss);
          let ele=tabl.nextElementSibling;
          let idno=0;
          let n=0;
          while(ele!=null){
            n=parseInt(ele.id.substring(5));
            n=n-1;
            ele.children[0].setAttribute('id','header'+n);
            ele.children[1].setAttribute('id','body'+n);
            ele.children[2].setAttribute('id','foot'+n);
            ele.id=ele.id.substring(0,5)+n;
            ele=ele.nextElementSibling;
          }
          tabl.remove();
        }
      }
    e.preventDefault();
  }
  if(e.target.id==='edit'){
    console.log(e.target.parentElement.parentElement);
    let ele=e.target.parentElement.parentElement.firstElementChild;
    let n=0;
    while(ele!=null){
      n=n+1;
      ele=ele.nextElementSibling;
    }
    console.log('no of elements='+n);

    if(n==3){
      const inp1=e.target.parentElement.parentElement.children[0].textContent.trim();
      e.target.parentElement.parentElement.children[0].innerHTML=`<input id='challenge' name='challenge' value='${inp1}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
      console.log('input1='+inp1);
      const inp2=e.target.parentElement.parentElement.children[1].textContent.trim();
      e.target.parentElement.parentElement.children[1].innerHTML=`
      <input id='points' value='${inp2}' name='points' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Points'>`;
      console.log('input2='+inp2);

      const inp3=e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].textContent.trim();
      e.target.parentElement.parentElement.parentElement.firstElementChild.children[1].innerHTML=`
      <input id='priority' value='${inp3}' name='priority' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Priority Name'>`;

      const inp4=e.target.parentElement.parentElement.parentElement.firstElementChild.children[2].textContent.trim();
      e.target.parentElement.parentElement.parentElement.firstElementChild.children[2].innerHTML=`
      <input id='subject' value='${inp4}' name='subject' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Subject Name'>`;

      e.target.parentElement.innerHTML=`<a href="" id="add">Add</a><a href="" id="delete">Delete</a><a href="" id="save">Save</a>`;
      
    }
    else if(n==6){
      const inp1=e.target.parentElement.parentElement.children[3].textContent.trim();
      e.target.parentElement.parentElement.children[3].innerHTML=`
      <input id='challenge' value='${inp1}' name='challenge' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
      console.log('input1='+inp1);

      const inp2=e.target.parentElement.parentElement.children[4].textContent.trim();
      e.target.parentElement.parentElement.children[4].innerHTML=`
      <input id='points' value='${inp2}' name='points' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Points'>`;
      console.log('input2='+inp2);

      const inp3=e.target.parentElement.parentElement.children[1].textContent.trim();
      e.target.parentElement.parentElement.children[1].innerHTML=`
      <input id='priority' value='${inp3}' name='priority' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Priority'>`;

      const inp4=e.target.parentElement.parentElement.children[2].textContent.trim();
      e.target.parentElement.parentElement.children[2].innerHTML=`
      <input id='subject' value='${inp4}' name='subject' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Subject Name'>`;

      e.target.parentElement.innerHTML=`<a href="" id="add">Add</a><a href="" id="delete">Delete</a><a href="" id="save">Save</a>`;
    }
    else if(n==2){
      const inp=e.target.parentElement.parentElement.firstElementChild.textContent.trim();
      e.target.parentElement.parentElement.firstElementChild.innerHTML=`
      <input id='sectionname' value='${inp}' name='sectionname' type='text' style='width:100%;text-align:center;border:none;' placeholder='Enter Section Name'>`;
      e.target.parentElement.innerHTML=`<a href="" id="add">Add</a><a href="" id="delete">Delete</a><a href="" id="save">Save</a>`;
    }
    e.preventDefault();
  }
  if(e.target.id==='saveall'){
    console.log("SAVED ALL");
    let headervalue=null;
    let idno=2;
    while(document.querySelector('#table'+idno)!=null){
      //header
      headervalue=document.querySelector('#header'+idno).firstElementChild.firstElementChild.textContent;
      document.querySelector('#header'+idno).firstElementChild.firstElementChild.innerHTML=`
      <input id='sectionname' name='sectionname' value='${headervalue}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Section Name'>
      `;
      //header
      
      //body
      let ele=document.querySelector('#body'+idno).firstElementChild;
      let elesubj=ele.children[2].textContent;
      ele.children[0].innerHTML=`
      <input id='sno' name='sno' value='${ele.children[0].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter SNo Name'>`;
      ele.children[1].innerHTML=`
      <input id='priority' name='priority' value='${ele.children[1].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter priority Name'>`;
      ele.children[2].innerHTML=`
      <input id='subject' name='subject' value='${ele.children[2].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Subject Name'>`;

      ele.children[3].innerHTML=`
      <input id='challengesnames' name='${elesubj}' value='${ele.children[3].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
      ele.children[4].innerHTML=`
      <input id='points' name='${elesubj+'points'}' value='${ele.children[4].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
      ele=ele.nextElementSibling;
      while(ele!=null){
        ele.children[0].innerHTML=`
        <input id='challengesnames' name='${elesubj}' value='${ele.children[0].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
        ele.children[1].innerHTML=`
        <input id='points' name='${elesubj+'points'}' value='${ele.children[1].textContent}' type='text' style='width:100%;height:100%;text-align:center;border:none;' placeholder='Enter Challenge Name'>`;
        ele=ele.nextElementSibling;
      }
      //body
      idno=idno+1;
    }
    //e.preventDefault();
  }
}