document.querySelector("#reviewers").style.backgroundColor="black";
document.querySelector("#reviewers").style.color="white";

const listhover=document.querySelector("#listofreviewers");
const search=document.querySelector("#searchbar");

listhover.addEventListener("click",listitemclick);
search.addEventListener("keyup",searchitem);

function listitemclick(e){
  document.querySelectorAll("#listofreviewers ul li a").forEach(function(item){
    item.style.backgroundColor="white";
    item.style.color="black";
  });
  e.target.style.backgroundColor='rgb(' + 43 + ',' + 96 + ',' + 222 + ')';
  e.target.style.color="white";
}

function searchitem(e){
  if(e.target.value.trim()!==""){
    document.querySelectorAll("#listofreviewers ul li a").forEach(function(listitem){
      if(listitem.textContent.trim().toLowerCase().includes(e.target.value.trim().toLowerCase())){
        listitem.parentElement.style.display="block";
      }
      else{
        listitem.parentElement.style.display="none";
      }
    });
  }
  else{
    document.querySelectorAll("#listofreviewers ul li").forEach(function(listitem){
        listitem.style.display="block";
    });
  }
}

document.querySelectorAll("#listofreviewers ul li a").forEach(function(item){
  if(item.href.trim().toLowerCase().includes(document.querySelector("#unamemail").textContent.trim().toLowerCase())){
    item.style.backgroundColor='rgb(' + 43 + ',' + 96 + ',' + 222 + ')';
    item.style.color="white";
  }
  else{
    item.style.backgroundColor="white";
    item.style.color="black";
  }
});
