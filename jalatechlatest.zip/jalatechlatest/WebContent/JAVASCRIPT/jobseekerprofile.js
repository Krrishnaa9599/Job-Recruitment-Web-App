document.querySelector("#profile").style.backgroundColor="black";
document.querySelector("#profile").style.color="white";
document.querySelector("#edit").addEventListener('click',editfunc);
document.querySelector("#save").addEventListener('click',savefunc);
document.querySelector('#save').style.display='none';

function editfunc(e){
  //console.log('edit clicked');

  //console.log(document.querySelector("#dob").textContent);
  let dob=document.querySelector("#dob").textContent.split('/');
  dob.reverse();
  document.querySelector("#dob").value=document.querySelector("#dob").textContent.replace('/','-');

  let jd=document.querySelector("#jd").textContent.split('/');
  jd.reverse();
  document.querySelector("#jd").value=document.querySelector("#jd").textContent.replace('/','-');

  const radionbtnvalue=document.querySelector("#gender").textContent.toLowerCase().trim();

  document.querySelector('#matter1').innerHTML=`<tr style="vertical-align:top;margin:0;padding:0;">
  <td><input type="text" name='firstname' id='firstname' value='${document.querySelector("#firstname").textContent.trim()}'></td>
  <td><input type="text" name='lastname' id='lastname' value='${document.querySelector("#lastname").textContent.trim()}'></td>
  <td><input type="date" name='dob' id='dob' value='${dob[0]+"-"+dob[1]+"-"+dob[2]}'></td>
  <td><input class='radiobtn' type="radio" name='gender' value='Male' id='male'><span>Male</span><input type="radio" class='radiobtn' name='gender' value='Female' id='female'><span>Female</span></td>
  </tr>`;

  document.querySelector('#matter2').innerHTML=`<tr style="vertical-align:top;margin:0;padding:0;">
  <td><input type="text" name='username' id='username' value='${document.querySelector("#username").textContent.trim()}'></td>
  <td><input type="text" id='mobileno' name='mobileno' value='${document.querySelector("#mobileno").textContent.trim()}'></td>
  <td><input type="date" id='jd' name='jd' value='${jd[0]+"-"+jd[1]+"-"+jd[2]}'></td>
  <td id='reviewer'>Yes</td>
  </tr>`;

  //console.log(document.querySelector("#gender").textContent);
  if(radionbtnvalue==='male'){
    document.getElementById("male").checked=true;
  }
  else{
    document.getElementById("female").checked=true;
  }
  document.querySelector("#edit").style.display='none';
  document.querySelector("#save").style.display='block';
  e.preventDefault();
}
function savefunc(e){
  console.log('save clicked');
  document.querySelector("#edit").style.display='block';

  let firstname=document.querySelector('#firstname').value.trim();
  let lastname=document.querySelector('#lastname').value.trim();
  let dob=document.querySelector('#dob').value;
  let male=document.querySelector('#male').checked;
  let female=document.querySelector('#female').checked;
  let username=document.querySelector('#username').value.trim();
  let mobileno=document.querySelector('#mobileno').value.trim();
  let jdate=document.querySelector('#jd').value;
  let reviewer=document.querySelector('#reviewer').textContent.trim();

  console.log(firstname.replace(/ /g, '+'));
  console.log(lastname.replace(/ /g, '+'));
  console.log(dob);
  console.log(male);
  console.log(female);
  console.log(username);
  console.log(mobileno);
  console.log(jdate);
  console.log(reviewer);

  let gender=false;
  if(male){
    gender='Male';
  }
  else{
    gender='Female';
  }
  
  // for(let t=0;t<firstname.length;t++){
  //   if(firstname[t]===' '){
  //     firstname[t].replace('+');
  //   }
  // }

  // for(let t=0;t<lastname.length;t++){
  //   if(lastname[t]===' '){
  //     lastname[t].replace('+');
  //   }
  // }
  
  const allitems=`firstname=${firstname.replace(/ /g, '+')}&lastname=${lastname.replace(/ /g, '+')}&dob=${dob}&gender=${gender}&username=${username}&mobileno=${mobileno}&jd=${jdate}&reviewer=${reviewer}`

  document.querySelector('#save').setAttribute('href','./jobseekersave?'+allitems);
  console.log('./jobseekersave?'+allitems);
  //e.preventDefault();
}