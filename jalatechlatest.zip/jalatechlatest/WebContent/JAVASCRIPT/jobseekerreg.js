const firstname=document.querySelector("#firstname");
const lastname=document.querySelector("#lastname");
const mobileno=document.querySelector("#mobileno");
const button=document.querySelector("#button");

firstname.addEventListener("blur",checkf);
lastname.addEventListener("blur",checkf);
mobileno.addEventListener("blur",checkf);
button.addEventListener("click",sub);

function checkf(e){
  if(/[^a-zA-Z ]/i.test(e.target.value) && e.target.value!=="" && (e.target!==mobileno)){
    e.target.nextSibling.textContent="Must contain alphabets only";
    e.target.style.borderColor="red";
  }
  if(/[^0-9]/i.test(e.target.value) && e.target.value!=="" && e.target===mobileno){
    e.target.nextSibling.textContent="Must contain numbers only";
    e.target.style.borderColor="red";
  }
  setTimeout(function(){
    Array.from(document.querySelectorAll("p")).forEach(function(para){
      para.textContent=" ";
      para.previousSibling.style.borderColor="green";
    });
  },5000);
  
}

function sub(e){
  const errarr=new Array();

  if(/[^a-zA-Z ]/i.test(firstname.value) && firstname.value!==""){
    firstname.nextSibling.textContent="Must contain alphabets only";
    firstname.style.borderColor="red";
    errarr.push(false);
  }
  if(/[^a-zA-Z ]/i.test(lastname.value) && lastname.value!==""){
    lastname.nextSibling.textContent="Must contain alphabets only";
    lastname.style.borderColor="red";
    errarr.push(false);
  }
  if(/[^0-9]/i.test(mobileno.value) && mobileno.value!==""){
    mobileno.nextSibling.textContent="Must contain numbers only";
    mobileno.style.borderColor="red";
    errarr.push(false);
  }
  //donotleaveemptycode
  Array.from(document.querySelectorAll("input")).forEach(function(inp){
    if(inp.value.trim()==="" && inp!==document.querySelector("#password")&& inp!==document.querySelector("#repassword")){
      inp.nextSibling.textContent="Do not leave empty";
      inp.style.borderColor="red";
      errarr.push(false);
    }
    else if(inp.value===""&& inp===document.querySelector("#password"))
    {
      inp.nextSibling.textContent="Do not leave empty";
      inp.style.borderColor="red";
      errarr.push(false);
    }
    else if(inp.value===""&& inp===document.querySelector("#repassword") )
    {
      inp.nextSibling.textContent="Do not leave empty";
      inp.style.borderColor="red";
      errarr.push(false);
    }
  });
  if(document.querySelector("#male").checked===false && document.querySelector("#female").checked===false && document.querySelector("#others").checked===false){
    document.querySelector("#others").nextSibling.nextSibling.textContent="Do not leave empty";
    errarr.push(false);
  }
  //donotleaveemptycode

  //password validation
  if((document.querySelector("#password").value!==document.querySelector("#repassword").value)&&(document.querySelector("#password").value!==""&&document.querySelector("#repassword").value!=="")){
    document.querySelector("#password").nextSibling.textContent="These fields must be same";
    document.querySelector("#repassword").nextSibling.textContent="These fields must be same";
    document.querySelector("#password").style.borderColor="red";
    document.querySelector("#repassword").style.borderColor="red";
    errarr.push(false);
  }
  //password validation
  setTimeout(function(){
    Array.from(document.querySelectorAll("p")).forEach(function(para){
      para.textContent=" ";
      para.previousSibling.style.borderColor="green";
    });
  },5000);

  if(errarr.length>0){
    e.preventDefault();
  }
}