const closeicon=document.querySelector("#closeicon");

closeicon.addEventListener("click",closebutton);
function closebutton(e){
  document.querySelector("#successbox").remove();
  document.querySelector("#successmsgmain").remove();
  window.location.href = "./jobseekerlogin";
  console.log("closed");
}