document.querySelectorAll("#reviewercheckbox").forEach(function(element){
element.disabled=true;
});