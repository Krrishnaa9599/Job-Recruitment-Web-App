<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.util.*,java.sql.*,com.jalatech.mysqlconnection.*" %>
<%
if(request.getParameter("id")!=null){
	
}
else{
	RequestDispatcher rd=request.getRequestDispatcher("/jobseekerlogin");
	rd.forward(request,response);
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%
Connection con=new DatabaseConnection().getDatabaseConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select * from context");
rs.beforeFirst();

while(rs.next()){
	out.println(rs.getString(3));
	out.println("<br>");
	if(request.getParameterValues(rs.getString(3))!=null){
	for(String subj:request.getParameterValues(rs.getString(3))){
		out.println(subj);
		out.println("<br>");
	}
	}
	
	out.println("<br>");
	out.println("<br>");
}

rs.beforeFirst();
while(rs.next()){
	st.addBatch("Update `"+rs.getString(3).toLowerCase().trim()+"` set `"+request.getParameter("id").toLowerCase().trim()+"`='unmarked'");
	if(request.getParameterValues(rs.getString(3))!=null){
	for(String ch:request.getParameterValues(rs.getString(3))){
		st.addBatch("Update `"+rs.getString(3).toLowerCase().trim()+"` set `"+request.getParameter("id").toLowerCase().trim()+"`='marked' where Challenges='"+ch+"'");
	}
	}
}
int rowCountss[]=st.executeBatch();

RequestDispatcher rd=request.getRequestDispatcher("/jobseekerchallenges?ids="+request.getParameter("id").toLowerCase().trim());
rd.forward(request,response); 
%>
</body>
</html>