<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*" %>
    
<%
String mark=request.getParameter("reviewercheckbox");
String id=request.getParameter("id");
if(mark!=null)
{
	mark="Yes";
}
else
{
	mark="No";
}
Connection con=new DatabaseConnection().getDatabaseConnection();
Statement st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
int rowCount=st.executeUpdate("update jobseekerreg set Reviewer='"+mark+"' where USER_NAME='"+id+"'");
con.close();

RequestDispatcher rd=request.getRequestDispatcher("/adminjobseeker?ids="+id);
rd.forward(request,response);
%>
