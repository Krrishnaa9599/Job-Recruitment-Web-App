<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*"%>
<%
String firstname=request.getParameter("firstname");
String lastname=request.getParameter("lastname");
String dob=request.getParameter("dob");
String gender=request.getParameter("gender");
String username=request.getParameter("username");
String mobileno=request.getParameter("mobileno");
String jdate=request.getParameter("jd");
String reviewer=request.getParameter("reviewer");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%
/* out.println("<p>"+firstname+"</p>");
out.println("<p>"+lastname+"</p>");
out.println("<p>"+dob+"</p>");
out.println("<p>"+gender+"</p>");
out.println("<p>"+username+"</p>");
out.println("<p>"+mobileno+"</p>");
out.println("<p>"+jdate+"</p>");
out.println("<p>"+reviewer+"</p>"); */

DatabaseConnection dc=new DatabaseConnection();
Connection con=dc.getDatabaseConnection();
Statement st=con.createStatement();
int rowCount=st.executeUpdate("Update jobseekerreg set FIRST_NAME='"+firstname+"',LAST_NAME='"+lastname+"',DATE_OF_BIRTH='"+dob+"',GENDER='"+gender+"',JOINING_DATE='"+jdate+"',MOBILE_NO='"+mobileno+"',USER_NAME='"+username+"',Reviewer='"+reviewer+"' where USER_NAME='"+username.trim()+"'");

RequestDispatcher rd=request.getRequestDispatcher("/jobseekerprofile");
request.setAttribute("username",username);
rd.forward(request,response);
%>

</body>
</html>