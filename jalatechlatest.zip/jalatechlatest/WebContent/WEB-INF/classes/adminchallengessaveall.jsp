<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.util.*,java.sql.*,com.jalatech.mysqlconnection.*" %>
<%
String priority[]=request.getParameterValues("priority");
String subject[]=request.getParameterValues("subject");
String sectionname[]=request.getParameterValues("sectionname");

/* out.println("SNo");
out.println("<br>");
for(String s1:request.getParameterValues("sno")){
out.println(s1);
out.println("<br>");
}
out.println("Priorities");
out.println("<br>");
for(String s1:priority){
out.println(s1);
out.println("<br>");
}
out.println("Section Name");
out.println("<br>");
for(String s1:request.getParameterValues("sectionname")){
out.println(s1);
out.println("<br>");
}
out.println("<br>");
out.println("Subjects");
out.println("<br>");

for(String s2:subject){
out.println("Subject: "+s2);
out.println("<br>");
for(String s:request.getParameterValues(s2)){
	out.println(s);
	out.println("<br>");
}
out.println("<br>");
}
out.println("<br>");

out.println("Subjects");
out.println("<br>");

for(String s2:subject){
out.println("Subject: "+s2);
out.println("<br>");
for(String s:request.getParameterValues(s2+"points")){
	out.println(s);
	out.println("<br>");
}
out.println("<br>");
} */  


ArrayList<String> databsubj=new ArrayList<String>();

Connection con=new DatabaseConnection().getDatabaseConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select * from context order by SNo");
rs.beforeFirst();
while(rs.next()){
	databsubj.add(rs.getString(3).toLowerCase().trim());
}
if(!databsubj.isEmpty()){
int rowCount=st.executeUpdate("truncate table context");
}
Statement st1=con.createStatement();
if(subject.length>0){
	for(int i=0;i<subject.length;i++){
		st1.addBatch("insert into context values('"+(i+1)+"','"+sectionname[i].trim()+"','"+subject[i].trim()+"','"+priority[i].trim()+"')");
	}
	int rowCountvalues[]=st1.executeBatch();
}
LinkedList<String> presentsubj=new LinkedList<String>();
LinkedList<String> absentsubj=new LinkedList<String>();
LinkedList<String> newsubj=new LinkedList<String>();

for(int i=0;i<subject.length;i++){
	if(databsubj.contains(subject[i].toLowerCase().trim())){
		presentsubj.add(subject[i].trim());
		databsubj.remove(subject[i].toLowerCase().trim());
	}
	else{
		newsubj.add(subject[i].trim());
	}
}
absentsubj.addAll(databsubj);
if(!absentsubj.isEmpty()){
	Statement st2=con.createStatement();
	Iterator<String> absentitr=absentsubj.iterator();
	while(absentitr.hasNext()){
		st2.addBatch("drop table `"+absentitr.next()+"`");
	}
	int rowCountabs[]=st2.executeBatch();
}
Statement st3;
ResultSet r3;
//LinkedList databch=new LinkedList();
LinkedHashMap<String,Integer> presentch=new LinkedHashMap<String,Integer>();
LinkedList<String> absentch=new LinkedList<String>();
LinkedHashMap<String,Integer> newch=new LinkedHashMap<String,Integer>();
LinkedHashMap<String,Integer> challenges=new LinkedHashMap<String,Integer>();

Iterator<String> presentitr=presentsubj.iterator();
//Iterator newchitr=null;
String psubj=null;
int index=1;
String points[]=null;
Statement st4;
Statement st5;
while(presentitr.hasNext()){
	st3=con.createStatement();
	psubj=presentitr.next().toString();
	r3=st3.executeQuery("select * from `"+psubj+"` order by SNo");
	index=1;
	for(String ch:request.getParameterValues(psubj)){
		challenges.put(ch.toLowerCase().trim(),index);
		index++;
	}
	while(r3.next()){
		if(challenges.containsKey(r3.getString(2).toLowerCase().trim())){
			presentch.put(r3.getString(2),challenges.get(r3.getString(2).toLowerCase().trim()));
			challenges.remove(r3.getString(2).toLowerCase().trim());
		}
		else{
			absentch.add(r3.getString(2));
		}
	}
	
	Statement stp=con.createStatement();
	Set<Map.Entry<String,Integer>> sp=presentch.entrySet();
	Iterator <Map.Entry<String,Integer>> spitr=sp.iterator();
	while(spitr.hasNext()){
		Map.Entry<String,Integer> m2=(Map.Entry<String,Integer>)spitr.next();
		stp.addBatch("Update `"+psubj+"` set SNo='"+m2.getValue()+"' where Challenges='"+m2.getKey()+"'");
	}
	//stp.addBatch("alter table "+psubj+" ORDER BY SNo ASC");
	int stprowCount[]=stp.executeBatch();
	
	Statement ordby=con.createStatement();
	int rowCount=ordby.executeUpdate("alter table `"+psubj+"` ORDER BY SNo");
	
	
	
	newch.putAll(challenges);
	st4=con.createStatement();
	points=request.getParameterValues(psubj+"points");
	Set<Map.Entry<String,Integer>> sm=newch.entrySet();
	Iterator<Map.Entry<String,Integer>> smitr=sm.iterator();
	while(smitr.hasNext()){
		Map.Entry<String,Integer> m1=(Map.Entry<String,Integer>)smitr.next();
		//System.out.println("Subject="+request.getParameterValues(psubj)[Integer.valueOf((Integer)m1.getValue())-1]);
		//System.out.println(points[Integer.valueOf((Integer)m1.getValue())-1]);
		
		String mob="insert into `"+psubj+"` values('"+(m1.getValue())+"','"+request.getParameterValues(psubj)[Integer.valueOf((Integer)m1.getValue())-1]+"','"+points[Integer.valueOf((Integer)m1.getValue())-1]+"'";
		Statement srrr=con.createStatement();
		ResultSet rrss=srrr.executeQuery("select count(USER_NAME) from jobseekerreg");
		rrss.beforeFirst();
		rrss.next();
		int norows=Integer.parseInt(rrss.getString(1));
		for(int ccc=0;ccc<norows;ccc++){
			mob=mob+",default";
		}
		mob=mob+")";
		st4.addBatch(mob);
	}
	int st4rowCount[]=st4.executeBatch();
	
	st5=con.createStatement();
	Iterator<String> absentchitr=absentch.iterator();
	while(absentchitr.hasNext()){
		st5.addBatch("delete from `"+psubj+"` where Challenges='"+absentchitr.next()+"'");
	}
	int st5rowCount[]=st5.executeBatch();
	
	challenges.clear();
	presentch.clear();
	absentch.clear();
	newch.clear();
	points=null;
	st4=null;
	st5=null;
	st3=null;
	r3=null;
}
//get all users

Statement stt=con.createStatement();
ResultSet rrrs=stt.executeQuery("select USER_NAME from jobseekerreg");

//get all users
Iterator<String> newsubjitr=newsubj.iterator();
Statement st7=con.createStatement();
while(newsubjitr.hasNext()){
	String nsubj=newsubjitr.next().toString();
	st7.addBatch("create table `"+nsubj+"` (SNo varchar(1000),Challenges varchar(1000),Points varchar(1000) default 0);");
	int sn=0;
	String[] point=request.getParameterValues(nsubj+"points");
	for(String chall:request.getParameterValues(nsubj)){
		st7.addBatch("insert into `"+nsubj+"` values('"+(sn+1)+"','"+chall+"','"+point[sn]+"')");
		sn++;
	}
	
	while(rrrs.next()){
		st7.addBatch("alter table `"+nsubj+"` add `"+rrrs.getString(1)+"` varchar(30) default 'unmarked' NOT NULL");
		//alter table js add helloo varchar(4) default '5' NOT NULL;
	}
}
st7.executeBatch();
con.close();
RequestDispatcher rd=request.getRequestDispatcher("/adminchallenges");
rd.forward(request,response);
%>