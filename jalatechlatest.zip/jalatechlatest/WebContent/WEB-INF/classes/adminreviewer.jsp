<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*" %>

<%
Connection con=new DatabaseConnection().getDatabaseConnection();
Statement st=con.createStatement();
ResultSet rs=st.executeQuery("select * from jobseekerreg");
%>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Job Seeker</title>
  <link rel="stylesheet" type="text/css" href="CSS/adminreviewer.css">
</head>
<body>
  <table id="layouttable">
    <tr style="height: 60px;">
      <td colspan="2">
      <ul id="navul">
        <li><a href="" id="home">Home</a></li>
        <li><a href="" id="leaderboard">Leader Board</a></li>
        <li><a href="./adminchallenges" id="challenges">Challenges</a></li>
        <li><a href="./adminjobseeker" id="jobseekers">Job Seekers</a></li>
        <li><a href="./adminreviewer" id="reviewers">Reviewers</a></li>
        <li><a href="./jobseekerreg" id="createjobseeker">Create Account for Job seeker</a></li>
        <li><a href="" id="logout">Logout</a></li>
      </ul>
      </td>
    </tr>
    <tr>
      <td style="width: 300px;vertical-align: top;">
        <div id="listofreviewerssection">
            <div id="searchsection">
              <input type="text" placeholder="Search" id="searchbar">
            </div>
            <div id="listofreviewers">
                 <ul>
                 <%
                 rs.beforeFirst();
                 while(rs.next())
                 {
                	 if(rs.getString(10).trim().equals("Yes"))
                	 {
                	 	out.println("<li><a href='./adminreviewer?ids="+rs.getString(8)+"'>"+rs.getString(2)+" "+rs.getString(3)+"</a></li>");
                	 }
                 }
                 %>

                  </ul>
            </div>
        </div>
      </td>
      <td>
        <div id="details">
          
        </div>
      </td>
    </tr>
  </table>
  <script src="JAVASCRIPT/adminreviewer.js"></script>
</body>
</html>