<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*,java.text.SimpleDateFormat"%>
<%
String username=request.getParameter("username");
String password=request.getParameter("password");

Connection con=new DatabaseConnection().getDatabaseConnection();
Statement stt=con.createStatement();
ResultSet rss=stt.executeQuery("select * from jobseekerreg where USER_NAME='"+username+"'");
rss.next();
%>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Job Seeker Profile</title>
  <link rel="stylesheet" type="text/css" href="CSS/jobseekerprofile.css">
</head>
<body>
  <div id="navbar">
    <ul>
      <li><a id="profile"href="">Profile</a></li>
      <li><a id="challenges" href="./jobseekerchallenges?ids=<%=request.getParameter("username")%>">Challenges</a></li>
    </ul>
    <a id="logout"href="">Logout</a>
  </div>
  <div id="matter">
    <table>
      <tr style="height:30px;">
        <td><label for='firstname'>First Name</label></td>
        <td><label for='lastname'>Last Name</label></td>
        <td><label for='dob'>Date Of Birth</label></td>
        <td><label for='gender'>Gender</label></td>
      </tr>
      <tr id='matter1' style="vertical-align:top;">
        <td id='firstname'><%=rss.getString(2).trim() %></td>
        <td id='lastname'><%=rss.getString(3).trim() %></td>
        <td id='dob'><%=new SimpleDateFormat("dd/MM/yyyy").format((java.sql.Date)rss.getDate(4))%></td>
        <td id='gender'><%=rss.getString(5).trim() %></td>
      </tr>
      

      <tr style="height:30px;">
        <td><label for='username'>User Name</label></td>
        <td><label for='mobileno'>Mobile No</label></td>
        <td><label for='jd'>Joining Date</label></td>
        <td><label for='reviewer'>Reviewer?</label></td>
      </tr>
      <tr id='matter2' style="vertical-align:top;">
        <td id='username'><%=rss.getString(8).trim()%></td>
        <td id='mobileno'><%=rss.getString(7).trim()%></td>
        <td id='jd'><%=new SimpleDateFormat("dd/MM/yyyy").format((java.sql.Date)rss.getDate(6))%></td>
        <td id='reviewer'><%=rss.getString(10).trim()%></td>
      </tr> 
    </table>
    <a href='' id="edit">Edit</a>
     <a id="save" href="">Save</a> 
  </div>
  <script src="JAVASCRIPT/jobseekerprofile.js"></script>
</body>
</html>