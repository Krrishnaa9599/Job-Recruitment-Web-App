<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Admin</title>
  <link rel="stylesheet" type="text/css" href="CSS/adminhome.css">
</head>
<body>
  <div id="navbar">
    <ul>
      <li><a href="./adminhome" id="home">Home</a></li>
      <li><a href="">Leader Board</a></li>
      <li><a href="./adminjobseeker">Job Seekers</a></li>
      <li><a href="./adminreviewer">Reviewers</a></li>
    </ul>
    <a href="" id="logout">Logout</a>
    <a id="createjobseeker" href="./jobseekerreg">Create Account for Job seeker</a>
  </div>
</body>
</html>