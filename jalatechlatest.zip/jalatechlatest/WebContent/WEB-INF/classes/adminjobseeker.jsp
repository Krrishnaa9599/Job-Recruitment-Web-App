<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*"%>
<%!
String jobseeker=null;
Connection con=null;
Statement st=null;
ResultSet rs=null;
int i=1;
RequestDispatcher rd=null;

String firstname=null;
String lastname=null;
String gender=null;
java.sql.Date jdate=null;
String mobileno=null;
java.sql.Date dob=null;
String username=null;
String reviewer=null;
%>

<%
con=new DatabaseConnection().getDatabaseConnection();
st=con.createStatement();

if(request.getParameter("ids")!=null){
ResultSet rs1=st.executeQuery("select * from jobseekerreg where USER_NAME='"+(request.getParameter("ids")).toString().trim()+"'");
rs1.first();

firstname=rs1.getString(2);
lastname=rs1.getString(3);
dob=rs1.getDate(4);
gender=rs1.getString(5);
jdate=rs1.getDate(6);
mobileno=rs1.getString(7);
username=rs1.getString(8);
reviewer=rs1.getString(10);
}
%>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Job Seeker</title>
  <link rel="stylesheet" type="text/css" href="CSS/adminjobseeker.css">
</head>
<body>
  <table id="layouttable">
    <tr style="height: 60px;">
      <td colspan="2">
      <ul id="navul">
        <li><a href="" id="home">Home</a></li>
        <li><a href="" id="leaderboard">Leader Board</a></li>
       <li><a href="./adminchallenges" id="challenges">Challenges</a></li>
        <li><a href="./adminjobseeker" id="jobseekers">Job Seekers</a></li>
        <li><a href="./adminreviewer" id="reviewers">Reviewers</a></li>
        <li><a href="./jobseekerreg" id="createjobseeker">Create Account for Job seeker</a></li>
        <li><a href="" id="logout">Logout</a></li>
      </ul>
      </td>
    </tr>
    <tr>
      <td style="width: 300px;vertical-align: top;">
        <div id="listofjobseekerssection">
            <div id="searchsection">
              <input type="text" placeholder="Search" id="searchbar">
            </div>
            <div id="listofjobseekers">
                 <ul>
                 <%
                 ResultSet rs=st.executeQuery("select * from jobseekerreg");
                  rs.beforeFirst();
                if(rs.next()==false)
                {
                  out.println("<li>No JobSeekers Registered Yet</li>");
                }
                else
                {
                  rs.beforeFirst();
                  while(rs.next())
                  {
                    out.println("<li><a href='./adminjobseeker?ids="+rs.getString(8)+"'>"+rs.getString(2)+" "+rs.getString(3)+"</a></li>");
                    i++;
                  }
                }
                %>
                  </ul>
            </div>
        </div>
      </td>
      <td>
        <div id="details">
          <!DOCTYPE html>
          <html lang="en">
          <head>
            <title>Job Seeker</title>
            <link rel="stylesheet" type="text/css" href="CSS/jobseekerdetails.css">
          </head>
          <body>
            <div>
              <table id="table1">
   			   <tr class="labels">
   			   <td>First Name:</td>
     		  <td>Last Name:</td>
      		  <td>Gender:</td>
 		     </tr>
     		 <tr class="values">
    		    <td><%=firstname %></td>
    		    <td><%=lastname %></td>
   		     <td><%=gender %></td>
   	   </tr>
   		   <tr class="labels">
     		   <td>Joining Date:</td>
		        <td>Mobile No:</td>
    		    <td>Date of Birth:</td>
   		   </tr>
		      <tr class="values">
      		  <td><%=jdate %></td>
      		  <td><%=mobileno %></td>
      		  <td><%=dob %></td>
      		</tr>
     		 <tr class="labels">
     		   <td>Username:</td>
     		   <td>Reviewer?:</td>
   			    <td>Make as Reviewer?:</td>
  		    </tr>
    		  <tr class="values">
   		     <td id="unamemail"><%=username %></td>
   		     <td id='reviewerstatus'><%=reviewer %></td>
   		     <form method="post" action="./adminjobseekersave?id=<%=username%>">
   		    <%
   		     if(reviewer!=null){
   		    	 if(reviewer.trim().equals("Yes"))
   		     	 {
   		    		out.println("<td><input name='reviewercheckbox' value='check' id='reviewercheckbox' type='checkbox' checked ></td>"); 
   		     	 }
   		     	 else
   		    	 {
   		    		out.println("<td><input name='reviewercheckbox' value='check' type='checkbox' id='reviewercheckbox'></td>");
   		     	 }
   		     }
   		     else
   		     {
   		    	out.println("<td><input name='reviewercheckbox' value='check' type='checkbox' id='reviewercheckbox'></td>");
   		     }
   		     %>
                    <input type="submit" value="Save" id="savebutton">
                </form>
		      </tr>
            </table>
            </div>
          </body>
          </html>
        </div>
      </td>
    </tr>
  </table>
  <script src="JAVASCRIPT/adminjobseeker.js"></script>
</body>
</html>