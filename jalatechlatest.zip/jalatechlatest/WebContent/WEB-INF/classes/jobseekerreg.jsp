<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Job Seeker Registration</title>
  <link rel="stylesheet" type="text/css" href="CSS/jobseekerreg.css">
</head>
<body>
  <div id="regblock">
    <h1 style="text-align: center;">JOB SEEKER REGISTRATION</h1>
    <form method="post" action="./jobseekerregsuccess">
      <table id=table1>
        <tr style="height: 20px;padding: 0;">
          <td style="padding: 0;"><label for="firstname">FIRST NAME</label></td>
          <td style="padding: 0;"><label for="lastname">LAST NAME</label></td>
          <td style="padding: 0;"><label for="dob">DATE OF BIRTH</label></td>
        </tr>
        <tr style="vertical-align:top;height: 40%;">
          <td><input id="firstname" name="firstname" type="text"><p> </p></td>
          <td><input id="lastname" name="lastname" type="text"><p> </p></td>
          <td><input id="dob" name="dob" type="date"><p> </p></td>
          
        </tr>
        <tr style="height: 20px;">
          <td><label for="gender">GENDER</label></td>
          <td><label for="jdate">JOINING DATE</label></td>
          <td><label for="mobileno">MOBILE NO</label></td>
        </tr>
        <tr style="vertical-align:top;height: 40%;">
          <td><input id="male" name="gender" type="radio" value="male"><span>Male</span>
          <input id="female" name="gender" type="radio" value="female"><span>Female</span>
          <input id="others" name="gender" type="radio" value="others"><span>Others</span><p> </p></td>
          <td><input type="date" name="jdate" id="jdate"><p> </p></td>
          <td><input type="text" name="mobileno" id="mobileno"><p> </p></td>
        </tr>
      </table>
      <table id="table2">
        <tr style="height: 20%;">
          <td><label style="font-size: 20px;" for="email">USER NAME</label></td>
          <td style="vertical-align: top;"><input type="text" id="email" name="email" placeholder="must be a valid email address"><p> </p></td>
        </tr>
        <tr style="height: 20%;">
          <td><label style="font-size: 20px;" for="password">PASSWORD</label></td>
          <td style="vertical-align: top;"><input type="password" name="password" id="password"><p> </p></td>
        </tr>
        <tr style="height: 20%;">
          <td><label style="font-size: 20px;" for="repassword">RE-ENTER PASSWORD</label></td>
          <td style="vertical-align: top;"><input id="repassword" name="repassword" type="password"><p> </p></td>
        </tr>
      </table>
      <input id="button" type="submit" value="SUBMIT">
    </form>
  </div>
  <script src="JAVASCRIPT/jobseekerreg.js"></script>
</body>
</html>