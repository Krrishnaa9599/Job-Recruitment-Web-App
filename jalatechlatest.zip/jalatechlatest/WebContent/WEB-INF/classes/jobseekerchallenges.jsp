<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<%
if(request.getParameter("ids")!=null){
	
}
else{
	RequestDispatcher rd=request.getRequestDispatcher("/jobseekerlogin");
	rd.forward(request,response);
}
%>

<%@page import="java.util.*,java.sql.*,com.jalatech.mysqlconnection.*" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Challenges</title>
  <link rel="stylesheet" type="text/css" href="CSS/jobseekerchallenges.css">
</head>
<body>
<form method='post' action="./jobseekerchallengessave?id=<%=request.getParameter("ids")%>">
  <div id="heading">
    <h2 id="head1">Challenges</h2>
    <h3 id="head2">(100 Points-15 Milestones)</h3>
    <input type='submit' value='Save' id='saveall'>
    <table border="1" id="table1">
    <tr>
      <td style="width: 5%;"><label>SNo</label></td>
      <td style="width: 5%;"><label>Priority</label></td>
      <td style="width: 20%;"><label>Subject</label></td>
      <td style="width: 40%;"><label>Challenges</label></td>
      <td style="width: 10%;"><label>Points</label></td>
      <td style="width: 10%;"><label>Job Seeker</label></td>
      <td style="width: 10%;"><label>Reviewer</label></td>
    </tr>
  </table>
  <% 
  Connection con=new DatabaseConnection().getDatabaseConnection();
  Statement st=con.createStatement();
  ResultSet rs=st.executeQuery("select * from context");
  rs.beforeFirst();
  int tableno=2;
  while(rs.next()){
  out.println("<table border='1' id='table"+tableno+"'>");
out.println("<thead>");
out.println("<tr style='background-color: rgb(57, 57, 235)'>");
out.println("<td colspan='7' style='width: 100%;'>"+rs.getString(2)+"</td>");
out.println("</tr>");
out.println("</thead>");
out.println("<tbody>");
out.println("<tr>");
Statement sc=con.createStatement();
ResultSet rc=sc.executeQuery("select count(Challenges) from `"+rs.getString(3)+"` order by SNo");
rc.beforeFirst();
rc.next();
int rowspan=Integer.parseInt(rc.getString(1));
out.println("<td rowspan='"+(rowspan+1)+"' style='width: 5%;'><label>"+rs.getString(1)+"</label></td>");
out.println("<td rowspan='"+(rowspan+1)+"' style='width: 5%;'><label>"+rs.getString(4)+"</label></td>");
out.println("<td rowspan='"+(rowspan+1)+"' style='width: 20%;'><label>"+rs.getString(3)+"</label></td>");
Statement stt=con.createStatement();
ResultSet rss=stt.executeQuery("select Challenges,Points from `"+rs.getString(3)+"` order by SNo");
rss.beforeFirst();
while(rss.next()){
out.println("<td style='width: 40%;'><label>"+rss.getString(1)+"</label></td>");
out.println("<td style='width: 10%;'><label>"+rss.getString(2)+"</label></td>");

Statement ssss=con.createStatement();
ResultSet rrrr=ssss.executeQuery("select `"+request.getParameter("ids")+"` from `"+rs.getString(3)+"` where Challenges='"+rss.getString(1)+"'");
rrrr.next();
String status=rrrr.getString(1);
if(status==null || rrrr.getString(1).toLowerCase().trim().equals("null")||rrrr.getString(1).toLowerCase().trim().equals("unmarked")){
	out.println("<td style='width: 10%;'><input type='checkbox' name='"+rs.getString(3)+"' value='"+rss.getString(1)+"'></td>");
	out.println("<td style='width: 10%;'><input type='checkbox' id='reviewercheckbox' name='points"+rs.getString(3)+"'></td>");
}
else if(status.toLowerCase().trim().equals("marked")){
	out.println("<td style='width: 10%;'><input type='checkbox' name='"+rs.getString(3)+"' value='"+rss.getString(1)+"' checked></td>");
	out.println("<td style='width: 10%;'><input type='checkbox' id='reviewercheckbox' name='points"+rs.getString(3)+"'></td>");
}
else if(status.toLowerCase().trim().equals("completed")){
	out.println("<td style='width: 10%;'><input id='reviewercheckbox' type='checkbox' name='"+rs.getString(3)+"' value='"+rss.getString(1)+"' checked></td>");
	out.println("<td style='width: 10%;'><input type='checkbox' id='reviewercheckbox' name='points"+rs.getString(3)+"' checked></td>");
}
out.println("</tr>");
}
out.println("</tbody>");
out.println("<tfoot>");
out.println("<tr style='background-color: rgb(230, 80, 105);'>");
out.println("<td colspan='3'></td>");
out.println("<td style='width: 20%;'><label>Total</label></td>");
out.println("<td colspan='3' style='width: 70%;'><label>10</label></td>");
out.println("</tr>");
out.println("</tfoot>");
out.println("</table>");

  tableno++;
  }
%>
</div>
</form>
<script src="JAVASCRIPT/jobseekerchallenges.js"></script>
</body>
</html>