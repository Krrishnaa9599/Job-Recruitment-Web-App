<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="java.sql.*,com.jalatech.mysqlconnection.*" %>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Challenges</title>
  <link rel="stylesheet" type="text/css" href="CSS/adminchallenges.css">
</head>
<body>
<form method='post' action='./adminchallengessaveall'>
  <div id="heading">
  
    <h2 id="head1">Challenges</h2>
    <h3 id="head2">(100 Points-15 Milestones)</h3>
    <input type='submit' id='saveall' value='Save All'>
    <table border="1" id="table1">
    <tr>
      <td style="width: 5%;">SNo</td>
      <td style="width: 5%;">Priority</td>
      <td style="width: 20%;">Subject</td>
      <td style="width: 50%;">Challenges</td>
      <td style="width: 5%;">Points</td>
      <td style="width: 15%;border:1px solid white;border-left: 1px solid black;"><a href="" id="newsection">Add New Section</a></td>
    </tr>
    </table>
  
    <%
    Connection con=new DatabaseConnection().getDatabaseConnection();
	Statement st=con.createStatement();
	Statement st1=con.createStatement();
	Statement st2=con.createStatement();
	ResultSet rs=st.executeQuery("select * from context order by SNo");
    	if(rs.next()!=false){
    		rs.beforeFirst();
    		int tableno=2;
    		int noofrows=0;
    		String sectionName=null;
    		
    		ResultSet rs1;
    		ResultSet rs2;
    		while(rs.next()){
    			sectionName=rs.getString(2);
    			
    			out.println("<table id='table"+tableno+"' border='1'>");
    			out.println("<thead id='header"+tableno+"'>");
    				out.println("<tr>");
    					out.println("<th colspan='5' style='background-color: #8DB4E2;'>"+sectionName+"</th>");
    						out.println("<th id='adddeleteeditsave' style='width: 15%; border-width: 1px; border-style: solid; border-color: white white white black; border-image: initial;'>");
    							out.print("<a href='' id='add'>Add</a>");
    							out.print("<a href='' id='delete'>Delete</a>");
    							out.print("<a href='' id='edit'>Rename</a>");
    						out.println("</th>");
    				out.println("</tr>");
    			out.println("</thead>");
    			
    			rs2=st2.executeQuery("select count(Challenges) from `"+rs.getString(3)+"`");
    			rs2.first();
    			noofrows=Integer.parseInt(rs2.getString(1));
    			//System.out.println("noofrows="+noofrows);
    			
    			rs1=st1.executeQuery("select * from `"+rs.getString(3)+"` order by SNo");//Java
    			rs1.beforeFirst();
    			
    			out.println("<tbody id='body"+tableno+"'>");
    				out.println("<tr>");
    					out.println("<td rowspan='"+(noofrows+1)+"' style='width: 5%;'>"+rs.getString(1)+"</td>");
    					out.println("<td rowspan='"+(noofrows+1)+"' style='width: 5%;'>"+rs.getString(4)+"</td>");
    					out.println("<td rowspan='"+(noofrows+1)+"' style='width: 20%;'>"+rs.getString(3)+"</td>");
    					rs1.next();
    					out.println("<td style='width: 50%;'>"+rs1.getString(2)+"</td>");
    					//System.out.println("Challenges="+rs1.getString(2));
    					out.println("<td style='width: 5%;'>"+rs1.getString(3)+"</td>");
    					//System.out.println("Points="+rs1.getString(3));
    					out.println("<td id='adddeleteeditsave' style='width: 15%;border:1px solid white;border-left: 1px solid black;'>");
    						out.print("<a href='' id='add'>Add</a>");
    						out.print("<a href='' id='delete'>Delete</a>");
    						out.print("<a href='' id='edit'>Rename</a>");
    					out.println("</td>");
    				out.println("</tr>");
    				while(rs1.next()){
    				out.println("<tr>");
    					out.println("<td style='width: 50%;'>"+rs1.getString(2)+"</td>");
    					out.println("<td style='width: 5%;'>"+rs1.getString(3)+"</td>");
    					out.println("<td id='adddeleteeditsave' style='width: 15%;border:1px solid white;border-left: 1px solid black;'>");
    						out.print("<a href='' id='add'>Add</a>");
    						out.print("<a href='' id='delete'>Delete</a>");
    						out.print("<a href='' id='edit'>Rename</a>");
    					out.println("</td>");
    				out.println("</tr>");
    				}
    			out.println("</tbody>");
    			out.println("<tfoot id='foot"+tableno+"'>");
    				out.println("<tr>");
    					out.println("<td colspan='3' style='background-color: #E6B8B7;'></td>");
    					out.println("<td style='width: 50%;background-color: #E6B8B7;'>Total</td>");
    					out.println("<td style='width: 5%;background-color: #E6B8B7;'>Points</td>");
    					out.println("<td style='width: 15%;border:1px solid white;border-left: 1px solid black;'><a href='' id='newsection'>Add New Section</a></td>");
    						
    					out.println("</td>");
    				out.println("</tr>");
    			out.println("</tfoot>");
    		out.println("</table>");
    			tableno++;
    		}
    	}
    %>
    
  </div>
  </form>
<script src="JAVASCRIPT/adminchallenges.js"></script>
</body>
</html>