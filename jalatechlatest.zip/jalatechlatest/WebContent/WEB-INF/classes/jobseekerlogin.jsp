<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Job Seeker Login</title>
    <link rel="stylesheet" type="text/css" href="CSS/jobseekerlogin.css">
</head>
<body>
    <div id="box1">

    </div>
    <div id="box2">
        <div id="loginbox">
            <h1 style="text-align:center">Job Seeker</h1>
            <form method="post" action="./jobseekerprofile">
                <table>
                    <tr>
                        <td><label>Username</label></td>
                    </tr>
                    <tr style="height:70px;vertical-align: top;">
                        <td><input type="text" id="username" name="username"><p> </p></td>
                        
                    </tr>
                    <tr>
                        <td><label>Password</label></td>
                    </tr>
                    <tr style="height:80px;vertical-align: top;">
                        <td><input type="password" id="password" name="password"><p> </p></td>
                        
                    <tr style="text-align:center">
                    <td><input id="button" value="LOGIN" type="submit"></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
    <script src="JAVASCRIPT/jobseekerlogin.js"></script>
</body>
</html>