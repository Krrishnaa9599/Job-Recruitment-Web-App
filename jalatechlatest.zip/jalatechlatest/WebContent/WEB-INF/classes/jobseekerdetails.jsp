<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@page import="com.jalatech.mysqlconnection.*,java.sql.*" %>
<%!
String firstname=null;
String lastname=null;
String gender=null;
java.sql.Date jdate=null;
String mobileno=null;
java.sql.Date dob=null;
String username=null;
 %>
 <%
 Connection con=new DatabaseConnection().getDatabaseConnection();
 Statement st=con.createStatement();
 ResultSet rs=st.executeQuery("select * from jobseekerreg where USER_NAME='"+(request.getAttribute("ids")).toString().trim()+"'");
 rs.first();
 
 firstname=rs.getString(2);
 lastname=rs.getString(3);
 dob=rs.getDate(4);
 gender=rs.getString(5);
 jdate=rs.getDate(6);
 mobileno=rs.getString(7);
 username=rs.getString(8);
 
 con.close();
 %>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Job Seeker</title>
  <link rel="stylesheet" type="text/css" href="CSS/jobseekerdetails.css">
</head>
<body>
  <div>
    <table id="table1">
      <tr class="labels">
        <td>First Name:</td>
        <td>Last Name:</td>
        <td>Gender:</td>
      </tr>
      <tr class="values">
        <td><%=firstname %></td>
        <td><%=lastname %></td>
        <td><%=gender %></td>
      </tr>
      <tr class="labels">
        <td>Joining Date:</td>
        <td>Mobile No:</td>
        <td>Date of Birth:</td>
      </tr>
      <tr class="values">
        <td><%=jdate %></td>
        <td><%=mobileno %></td>
        <td><%=dob %></td>
      </tr>
      <tr class="labels">
        <td>Username:</td>
        <td>Reviewer?:</td>
        <td>Make as Reviewer?:</td>
      </tr>
      <tr class="values">
        <td><%=username %></td>
        <td>Yes</td>
        <td><input type="checkbox" checked></td>
      </tr>
    </table>
    <a href="" id="savebutton">Save</a>
  </div>
</body>
</html>